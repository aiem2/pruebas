# prueba_viajes_chile

Generación de página web de operador turístico, utilizando HTML 5, CSS, Bootstrap (elementos: navbar, carousel y card) y JQuery (elementos: tooltip para los títulos de destacados y toggle para la descripción de los destacados).

Resultado en https://aiem2.github.io/prueba_viajes_chile/
